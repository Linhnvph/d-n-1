/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package thuchanh1_duanmau;

/**
 *
 * @author admin
 */
public class ThucHanh1_DuAnMau {

    public static void main(String[] args) {
       
    }
    
}
